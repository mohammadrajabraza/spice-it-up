import Input from './Input';

export * from './input.types';

export default Input;
